#!/bin/sh


# Change to working directory for unit
cd /worka/work/fbettenc/radical.pilot.sandbox/rp.session.corri.feb23.017311.0000-pilot.0000/unit.000016
# Environment variables
export RP_SESSION_ID=rp.session.corri.feb23.017311.0000
export RP_PILOT_ID=pilot.0000
export RP_AGENT_ID=agent_0
export RP_SPAWNER_ID=agent_0.AgentExecutingComponent.0.child
export RP_UNIT_ID=unit.000016

# Pre-exec commands
source activate ~/coco02
export PATH=/home/fbettenc/coco02/bin:$PATH
export PYTHONPATH=/home/fbettenc/coco02/lib/python2.7/site-packages:$PYTHONPATH
# The command to run
/usr/local/packages/mvapich2/2.0/INTEL-14.0.2/bin/mpiexec -n 4 -host smic129 pyCoCo "--grid" "30" "--dims" "3" "--frontpoints" "4" "--topfile" "md-0_0.gro" "--mdfile" *.xtc "--output" "coco_out_0.gro" "--logfile" "coco.log" "--selection" "name CA" 
RETVAL=$?
# Exit the script with the return code from the command
exit $RETVAL
