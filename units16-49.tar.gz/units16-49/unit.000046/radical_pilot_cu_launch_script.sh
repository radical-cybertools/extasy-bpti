#!/bin/sh


# Change to working directory for unit
cd /worka/work/fbettenc/radical.pilot.sandbox/rp.session.corri.feb23.017311.0000-pilot.0000/unit.000046
# Environment variables
export RP_SESSION_ID=rp.session.corri.feb23.017311.0000
export RP_PILOT_ID=pilot.0000
export RP_AGENT_ID=agent_0
export RP_SPAWNER_ID=agent_0.AgentExecutingComponent.0.child
export RP_UNIT_ID=unit.000046

# Pre-exec commands
module load gromacs/5.0/INTEL-140-MVAPICH2-2.0
source activate coco02
# The command to run
/bin/bash "-l" "-c" "echo System | gmx trjconv -f md-1_1.xtc -o md-1_1_whole.xtc -s md-1_1.tpr -pbc whole" 
RETVAL=$?
# Exit the script with the return code from the command
exit $RETVAL
