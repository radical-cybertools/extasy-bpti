#!/bin/sh


# Change to working directory for unit
cd /worka/work/fbettenc/radical.pilot.sandbox/rp.session.js-17-43.jetstream-cloud.org.hal9000.017331.0001-pilot.0000/unit.000152
# Environment variables
export RP_SESSION_ID=rp.session.js-17-43.jetstream-cloud.org.hal9000.017331.0001
export RP_PILOT_ID=pilot.0000
export RP_AGENT_ID=agent_0
export RP_SPAWNER_ID=agent_0.AgentExecutingComponent.0.child
export RP_UNIT_ID=unit.000152

# Pre-exec commands
module load gromacs/5.0/INTEL-140-MVAPICH2-2.0
source activate coco02
# The command to run
/usr/local/packages/mvapich2/2.0/INTEL-14.0.2/bin/mpiexec -n 20 -host smic081 gmx mdrun "-deffnm" "eq-1_11" 
RETVAL=$?
# Exit the script with the return code from the command
exit $RETVAL
