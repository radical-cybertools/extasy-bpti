#!/bin/bash


cow=`seq -w 16 33 643`
echo $cow
#cpto=/work/fbettenc/radical.pilot.sandbox/rp.session.corri.feb23.017311.0000-pilot.0000/cocozips

cpto=/work/fbettenc/radical.pilot.sandbox/rp.session.corri.feb23.017323.0000-pilot.0000/mass_grtr_than_2

for i in $cow ; 
	do cd unit.000$i/ ; 
	echo unit.000$i ;  
	cp coco.log $cpto/unit.000$i.coco.log ; 
	cd ..;  
	done
